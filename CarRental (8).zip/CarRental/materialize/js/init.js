(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();
    $('.slider').slider();
    $('.carousel').carousel();
    $('.modal').modal();

  }); // end of document ready
})(jQuery); // end of jQuery name space