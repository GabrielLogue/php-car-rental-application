<!Doctype html>
<head>
</head>
<body>
<p> Please enter your userName and Password! </p>
<form action="Authentication/index.php" method="POST">
<input name="username" type="text"/>
<br />
<input name = "password" type="password"/>
<input type="hidden" name="action" value="Authenticate"/>
<input type="submit" value="submit"/>
</form>
</body>
<a href="AccountSignUp/signup.php"/>Don't have an account? Sign Up Now!</a>
</html>