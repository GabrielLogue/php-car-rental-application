-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2018 at 03:48 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `CarID` int(11) NOT NULL,
  `CarName` varchar(50) NOT NULL,
  `CarType` varchar(15) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `IsOut` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`CarID`, `CarName`, `CarType`, `Description`, `IsOut`) VALUES
(1, '2018 Honda Civic', 'Compact', 'Such a good car with great gas mileage!', 0),
(2, '2018 Chevrolet Cruze', 'Compact', 'Another great car for the economy minded', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rentalorderin`
--

CREATE TABLE `rentalorderin` (
  `OrderInID` int(11) NOT NULL,
  `OrderOutID` int(11) NOT NULL,
  `mileage` decimal(10,0) NOT NULL,
  `finalPrice` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rentalorderin`
--

INSERT INTO `rentalorderin` (`OrderInID`, `OrderOutID`, `mileage`, `finalPrice`) VALUES
(1, 7, '20', 46.3),
(2, 7, '20', 46.3),
(3, 7, '20', 46.3);

-- --------------------------------------------------------

--
-- Table structure for table `rentalorderout`
--

CREATE TABLE `rentalorderout` (
  `OrderOutID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `CarID` int(11) NOT NULL,
  `DaysOut` int(11) NOT NULL,
  `PreliminaryPrice` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rentalorderout`
--

INSERT INTO `rentalorderout` (`OrderOutID`, `UserID`, `CarID`, `DaysOut`, `PreliminaryPrice`) VALUES
(7, 3, 1, 2, 39.9);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `IsAdmin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `UserName`, `Password`, `IsAdmin`) VALUES
(3, 'gabelogue18@gmail.com', '$2y$10$FTdvUTHiUDkXyx1uw85iZOWOx8kJwZJzzdeUZsBPYVYO4KrY4CMme', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`CarID`);

--
-- Indexes for table `rentalorderin`
--
ALTER TABLE `rentalorderin`
  ADD PRIMARY KEY (`OrderInID`),
  ADD KEY `OrderOutID` (`OrderOutID`);

--
-- Indexes for table `rentalorderout`
--
ALTER TABLE `rentalorderout`
  ADD PRIMARY KEY (`OrderOutID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CarID` (`CarID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `CarID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rentalorderin`
--
ALTER TABLE `rentalorderin`
  MODIFY `OrderInID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `rentalorderout`
--
ALTER TABLE `rentalorderout`
  MODIFY `OrderOutID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `rentalorderin`
--
ALTER TABLE `rentalorderin`
  ADD CONSTRAINT `rentalorderin_ibfk_1` FOREIGN KEY (`OrderOutID`) REFERENCES `rentalorderout` (`OrderOutID`);

--
-- Constraints for table `rentalorderout`
--
ALTER TABLE `rentalorderout`
  ADD CONSTRAINT `rentalorderout_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  ADD CONSTRAINT `rentalorderout_ibfk_2` FOREIGN KEY (`CarID`) REFERENCES `cars` (`CarID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
