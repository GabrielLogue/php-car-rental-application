 <!DOCTYPE html>
<head>
  <link href="../https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../materialize/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../materialize/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <nav class="nav-extended blue lighten 1 col s12">
    <div class="nav-wrapper blue lighten 1">
      <a href="#!" class="brand-logo center">Cars</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.php">Home</a>
          <li><a href="../Authentication/logout.php">Logout</a>
      </ul>
    </div>
    <div class="sidenav left hide-on-med-and-large">
    </div>
    <div class="nav-content">
      <span class="nav-title"></span>
    </div>
  </nav>  
        <div class="row">
        <div class="col s12 m6">
          <div class="card blue-grey darken-1">
            <div class="card-content white-text">
              <span class="card-title">Card Title</span>
              <p>Thank you <?php echo $UserName?>, for renting the <?php echo $CarName ?>from our list of <?php echo $CarType?> Vehicles. Your preliminary price is $<?php echo $Price?>. The Rest of your charge will be calculated when you bring the car back based on your mileage! We appreciate your patronage!</p>
              <div class="card-action">
              <a href="index.php">go back to our list of vehicles</a>
            </div>
          </div>
        </div>
      </div>
            