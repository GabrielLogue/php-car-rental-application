<?php
require('../Models/database.php');
require('../Models/cars.php');
require('../Models/users.php');
require('../Models/Orders.php');
session_start();
if (isset($_POST['action'])) {

	$action = $_POST['action'];

} //else if (isset($_GET['action'])) {

	//$action = $_GET['action'];
//} 
	else {
	$action = 'list_Cars';

}
 	if(isset($_SESSION["UserName"]))
	{
	$UserName = $_SESSION["UserName"];
}

else
{
	$UserName = 'not found';
}

 	if(isset($_SESSION["Loggedin"]))
	{
	$Loggedin = $_SESSION["Loggedin"];
}

else{
	$Loggedin = false;
}

if($Loggedin === true)
{
switch($action)
{
	case 'list_Cars':
	//$ACars = new Cars;
	 $ACars = getCars();
	include('CarView.php');
	//echo $ACars->CarName;	 //echo $UserName;
	

	//echo $ACars->CarType;
	//echo $ACars->Description;
	break;


	case 'Compact':
	//$ACars = new Cars;
	 $ACars = CompactCars();
	include('CarView.php');
	//echo $ACars->CarName;	 //echo $UserName;
	

	//echo $ACars->CarType;
	//echo $ACars->Description;
	break;

	case 'Standard':
	//$ACars = new Cars;
	 $ACars = StandardCars();
	include('CarView.php');
	//echo $ACars->CarName;	 //echo $UserName;
	

	//echo $ACars->CarType;
	//echo $ACars->Description;
	break;


	case 'Luxury':
	//$ACars = new Cars;
	 $ACars = LuxuryCars();
	include('CarView.php');
	//echo $ACars->CarName;	 //echo $UserName;
	

	//echo $ACars->CarType;
	//echo $ACars->Description;
	break;


	case 'Rent_Car':
	 $UserName = $_SESSION['UserName'];
	 //echo $UserName;
	 //$AUser = getUser($UserName);
	 
	 //foreach($AUser as $User):

	 //endforeach;
	$CarID = $_POST['CarID'];
	$CarName = $_POST['CarName'];
	$CarType = $_POST['CarType'];
	$Description = $_POST['Description'];
	$IsOut = $_POST['IsOut'];
	include('CheckOut.php');
	//echo $CarID;
	

	//echo $CarID;
	//echo $CarName;
	//echo $CarType;
	//echo $IsOut;
	//header('Location: '.$newURL);
	//echo $CarID;
	//case 'add_thoughts':
	//$SkillID=$_POST['SkillID'];
	//$ThoughtName = $_POST['ThoughtName'];
	//$Code = $_POST['Code'];
	//$Description = $_POST['Description'];
	//add_thoughts($ThoughtName,$Code,$Description);
	//$Thoughts = getThoughts();
    break;

    case 'confirm':
    $CarID = $_POST['CarID'];
    $Days = $_POST['Days'];
    //$Price = $_POST['Price'];
    $CarName = $_POST['CarName'];
    $UserName = $_POST['UserName'];
    $CarType = $_POST['CarType'];
    $IsOut = $_POST['IsOut'];
    $AUser = getUser($UserName); 
    //echo $CarID;
    //echo $Days;
    //echo $Price;
    //echo $UserName;
    if($IsOut == 0)
	{
		if($CarType == 'Compact')
		{
			$Price  = 19.95;
			$IsOut = 1;
			updateIsOut($CarID, $IsOut);
			//include('CheckOut.php');
			//echo $IsOut;
			//echo $Price;
		}

		else if($CarType == 'Standard')
		{
			$Price = 24.95;
			$IsOut = 1;
			updateIsOut($CarID, $IsOut);
			//include('CheckOut.php');
			//echo $IsOut;
			//echo $Price;
		}  

		else if ($CarType == 'Luxury')
		{
			$Price = 39.00;
			$IsOut = 1;
			updateIsOut($CarID, $IsOut);
			//include('CheckOut.php');
			//echo $IsOut;
			//echo $Price;
		}
		//updateIsOut($CarID, $IsOut);
		$Price = $Price * $Days;
	}

	else{
		echo 'sorry, this car is out at the moment';
	}
   foreach($AUser as $User) :
   OrderOut($CarID,$User['UserID'],$Days, $Price);
   	//echo $User['UserID'];
	//endforeach;
	$ACars = getCars();
	//include('CarView.php');
	endforeach;
	include('thankyou.php');
	break;
	//case 'delete_thoughts':
//ThoughtID = $_POST['ThoughtID'];
	//delete_thoughts($ThoughtID);
	//$Thoughts = getThoughts();
	//header("Location: .?");
	//include('ThoughtView.php');

	/*case 'edit_thoughts':
		$Thoughts = getThoughts();
	  	$ThoughtID = $_POST['ThoughtID'];
	  	$ThoughtName = $_POST['ThoughtName'];
	  	$Code = $_POST['Code'];
	  	$Description = $_POST['ThoughtDescription'];
    		//include('editskill.php');
    		header("Location: editthoughts.?ThoughtID=$ThoughtID&ThoughtName=$ThoughtName&Code=$Code&Description=$Description");
    	case 'edit':

    		$ThoughtID = $_POST['ThoughtID'];
    		$Name = $_POST['Name1'];
    		$Code = $_POST['Code1'];
    		$ThoughtDescription = $_POST['Description1'];
    		update_thought($ThoughtID,$Name,$Code,$ThoughtDescription);
    		$Thoughts = getThoughts();
    		include('ThoughtView.php');
    		break;*/
    }
}

else
{
	echo 'NOT LOGGED IN!';
}


?>