 <!DOCTYPE html>
<head>
  <link href="../https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../materialize/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../materialize/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <nav class="nav-extended blue lighten 1 col s12">
    <div class="nav-wrapper blue lighten 1">
      <a href="#!" class="brand-logo center">Cars</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.php">Home</a>
          <li><a href="../Authentication/logout.php">Logout</a>
      </ul>
    </div>
    <div class="sidenav left hide-on-med-and-large">
    </div>
    <div class="nav-content">
      <span class="nav-title"></span>
    </div>
  </nav>  
<div id="main">
<div id="content">



  <div id="main" class="container">
  <div class="row">


 <div class="col l6 m12 s12">
          <div class="card green lighten 3">
            <div class="card-image">
              <img src="<?php echo "../images/" . $CarName. ".jpg" ?>" width="300" height="300">
              <span class="card-title"><?php echo $CarName?></span>
            </div>
            <div class="card-content">
              <?php echo $Description?>
            </div>
        </div>
    </div>
</div>
</div>
<label for="daysform">Please Enter the number of Days you want to rent this vehicle</label>
<form name="daysform" action="index.php" method="post">
	<input type = "text" name = "Days"/>
  <input type="hidden" name="action" value="confirm"/>
  <input type="hidden" name="CarType" value="<?php echo $CarType?>"/>
  <input type="hidden" name="CarID" value="<?php echo $CarID?>"/>
  <input type="hidden" name="UserName" value="<?php echo $UserName?>"/>
  <input type="hidden" name="CarName" value="<?php echo $CarName?>" />
  <input type="hidden" name="IsOut" value="<?php echo $IsOut?>"/>
	<input type = "submit" name="submit" value="submit"/>
</form>