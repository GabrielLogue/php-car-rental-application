<!Doctype html>
<head>
</head>
<body>
<h1>Thank you for signing up with us!</h1>
<a href="../index.php">Return home</a>
</body>
</html>