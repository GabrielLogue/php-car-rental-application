<?php
require('../Models/database.php');
require('../Models/users.php');

if (isset($_POST['action'])) {

	$action = $_POST['action'];

} else if (isset($_GET['action'])) {

	$action = $_GET['action'];
} else {
	$action = 'list_Cars';

}

switch($action)
{
	case 'signup':
	include('signup.php');
	$username = $_POST['username'];
	$password = $_POST['password'];
	$password = password_hash($password, PASSWORD_DEFAULT);
	$isAdmin= $_POST['isAdmin'];
	$Users = getUsers();
	foreach($Users as $User):
	if($username == $User['UserName'])
	{
		echo 'an account with this username already exists';
	}
	else
	{
		AddUser($username,$password,$isAdmin);
		include('thankyou.php');
	}
	endforeach;
	break;

}
?>