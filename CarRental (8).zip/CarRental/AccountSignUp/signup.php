<?php
$false = 0;
$true = 1;

?>

<!Doctype html>
<head>
</head>
<body>
<p>please enter your username and password to create an account with us!</p>
<form action="index.php" method="POST" value="signup">
<input name="username" type="text"/>
<br />
<input name = "password" type="text"/>
<br />
<input name="isAdmin" type="hidden" value="<?php echo $false;?>"/>
<input type="hidden" name="action" value="signup" />
<input type="submit" value="Submit">
</form>
<a href="AccountSignUp/signup.php"/>Don't have an account? Sign Up Now!</a>
</html>