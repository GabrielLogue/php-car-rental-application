<?php

//class Cars{
   //public $CarName ='';
    //public $CarType = '';
    //public $Description = '';
   //public $IsOut = 0;
//} 
 function getCars() {
global $db;
$query = 'SELECT * FROM cars
      WHERE cars.IsOut = 0
			ORDER BY CarID';
		$Cars = $db->query($query);
		return $Cars;
  }

  function CompactCars()
  {
    global $db;
$query = "SELECT * FROM cars
      WHERE cars.CarType = 'Compact' AND cars.IsOut = 0
      ORDER BY CarID";
    $Cars = $db->query($query);
    return $Cars;
  }

  function StandardCars()
  {
    global $db;
$query = "SELECT * FROM cars
      WHERE cars.CarType = 'Standard' AND cars.IsOut = 0
      ORDER BY CarID";
    $Cars = $db->query($query);
    return $Cars;
  }

    function LuxuryCars()
  {
    global $db;
$query = "SELECT * FROM cars
      WHERE cars.CarType = 'Standard' AND cars.IsOut = 0
      ORDER BY CarID";
    $Cars = $db->query($query);
    return $Cars;
  }
    function updateIsOut($CarID, $IsOut)
    {
      global $db;
      $query = "UPDATE cars
                SET cars.IsOut = '$IsOut'
                WHERE cars.CarID = '$CarID'";
                $db->exec($query);

    }
function Car($CarID)
    {
      global $db;
     $query =  "SELECT * FROM cars
      WHERE cars.CarID = '$CarID'
      ORDER BY CarID";
    $Car = $db->query($query);
    return $Car;
    }
    

   // function OrderOut($User)
  
  ?>