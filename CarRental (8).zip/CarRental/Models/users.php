 
<?php
 function AddUser($UserName, $Password, $IsAdmin) {
    global $db;
    $query = "INSERT INTO users(UserName, Password, IsAdmin) VALUES ('$UserName', '$Password', '$IsAdmin')";
    $db->exec($query);
  }

  function getUser($UserName)
{
	global $db;
			$query = "SELECT * FROM users
			WHERE users.UserName = '$UserName' ORDER BY users.userID";
		 $user = $db->query($query);
     return $user;
}

function getUsers()
{
  global $db;
  $query = "SELECT * FROM users
     ORDER BY users.userID";
     $user = $db->query($query);
      return $user;
}

  ?>
