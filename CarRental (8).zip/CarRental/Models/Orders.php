<?php

function OrderOut($CarID, $UserID,$DaysOut, $Price)
{
	global $db;
    $query = "INSERT INTO rentalorderout(UserID, CarID, DaysOut,PreliminaryPrice) VALUES ('$UserID', '$CarID', '$DaysOut', $Price)";
    $db->exec($query);
}

function OrderIn($OrderOutID, $Mileage, $FinalPrice)
{
	global $db;
    $query = "INSERT INTO rentalorderin(OrderOutID, mileage, finalPrice) VALUES ('$OrderOutID', '$Mileage', '$FinalPrice')";
    $db->exec($query);
}
function GetOrderOut($UserID)
{
	global $db;
$query = "SELECT * FROM rentalorderout
      WHERE rentalorderout.UserID = '$UserID'
			ORDER BY OrderOutID";
		$Orders= $db->query($query);
		return $Orders;
}


function GetOrderByID($OrderID)
{
	global $db;
$query = "SELECT * FROM rentalorderout
      WHERE rentalorderout.OrderOutID= '$OrderID'
			ORDER BY OrderOutID";
		$Orders= $db->query($query);
		return $Orders;
}

?>