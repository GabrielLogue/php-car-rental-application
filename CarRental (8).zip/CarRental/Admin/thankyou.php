 <?php 


 foreach($Orders as $Order):
 	//echo 'Price' . ''. $Order['PreliminaryPrice'];
  echo 'PreliminaryPrice' . $Order['PreliminaryPrice'] . '<br />';
  echo 'Price for Miles' . $MileagePrice . '<br />';
 	$Price = $Order['PreliminaryPrice'] + $MileagePrice;
  echo 'Full Price:' . $Price;
OrderIn($Order['OrderOutID'], $Mileage, $Price);
 endforeach;
?>
<form name="returncar" action="index.php" method="post">
<input type="hidden" name="action" value="paid"/>
<input type="submit" value="paid and returned"/>
</form>