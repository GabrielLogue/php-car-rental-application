<head>
  <link href="../https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../materialize/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../materialize/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <nav class="nav-extended blue lighten 1 col s12">
    <div class="nav-wrapper blue lighten 1">
      <a href="#!" class="brand-logo center">Cars</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.php">Home</a>
      </ul>
    </div>
    <div class="sidenav left hide-on-med-and-large">
    </div>
    <div class="nav-content">
      <span class="nav-title"></span>
    </div>
  </nav>  
<div id="main">
<div id="content">



  <div id="main" class="container">
  <div class="row">


 <div class="col l6 m12 s12">
     
<label for="AdminForm" >Enter the User</label>    
<form name="AdminForm" action="index.php" method="post">
  <input type = "text" name = "UserName"/>
  <input type="hidden" name="action" value="Admin"/>
  <input type="submit" name="submit" value="submit"/>
</form>
</div>
</div>