<!DOCTYPE html>

<head>
  <link href="../https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../materialize/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../materialize/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <nav class="nav-extended blue lighten 1 col s12">
    <div class="nav-wrapper blue lighten 1">
      <a href="#!" class="brand-logo center">Cars</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.php">Home</a>
      </ul>
    </div>
    <div class="sidenav left hide-on-med-and-large">
    </div>
    <div class="nav-content">
      <span class="nav-title"></span>
    </div>
  </nav>  
<div id="main">
<div id="content">



  <div id="main" class="container">
  <div class="row">
<?php foreach ($Orders as $Order) : ?>
<?php $Cars = Car($Order['CarID']);?>
<div class="row">
        <div class="col s12 m6">
          <div class="card blue-grey darken-1">
            <div class="card-content white-text">
              <span class="card-title"><?php echo 'OrderID' . ' ' .  $Order['OrderOutID'];?></span>
              <p><?php echo 'Price' . ' ' .  $Order['PreliminaryPrice'];?></p><br />
              <?php foreach ($Cars as $Car): ?>
              <p><?php echo 'Car' . ' ' . $Car['CarName'];?> 
                <?php $_SESSION["CarID"] = $Car['CarID'];?>
              <?php endforeach;?>          
               </div>
            <div class="card-action">
              <?php $_SESSION["OrderID"] = $Order['OrderOutID'];?>
              <a href='Mileage.php'>Add mileage to the charge</a>
            </div>
          </div>
        </div>
      </div>

<?php endforeach;?>