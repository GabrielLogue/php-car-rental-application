<?php
session_start();
require('../Models/database.php');
require('../Models/cars.php');
require('../Models/users.php');
require('../Models/Orders.php');

if (isset($_POST['action'])) {

	$action = $_POST['action'];

} else if (isset($_GET['action'])) {

	$action = $_GET['action'];
} 
	else {
	$action = 'Orders'; 
}

	if(isset($_SESSION["Loggedin"]))
	{
	$Loggedin = $_SESSION["Loggedin"];
}



else{
	$Loggedin = false;
}

if($Loggedin === true)
{
switch($action)
{
	case 'Orders':
	include('Admin.php');
	break;

	case 'Admin':
	$UserName = $_POST["UserName"];
	$AUser = getUser($UserName); 
	foreach($AUser as $User) :
		$Orders = GetOrderOut($User['UserID']);
	endforeach;
	include('AdminUsers.php');
	break;

case 'Mileage':
if(isset($_SESSION["OrderID"]))
	{
	$OrderOutID = $_SESSION["OrderID"];
}



else{
  echo 'no orderID';
}

if (isset($_POST["Mileage"])) 
{

	$Mileage = $_POST["Mileage"];
	$MileagePrice = $Mileage * 0.32;
}

else{
	$MileagePrice = 0;
}

 echo $OrderOutID . '<br />';
 //echo $Price;
 $Orders = GetOrderByID($OrderOutID);
include('thankyou.php');
break;

case 'paid':
	if(isset($_SESSION["CarID"]))
	{
	$CarID = $_SESSION["CarID"];
}
$IsOut = 0;
	updateIsOut($CarID,$IsOut);
}
}

else{
	echo 'NOT LOGGED IN!';
}
?>