<?php
require('../Models/database.php');
require('../Models/users.php');
session_start();

if (isset($_POST['action'])) {

	$action = $_POST['action'];

} else if (isset($_GET['action'])) {

	$action = $_GET['action'];
} else {
	$action = 'list_Cars';

}

//class user{
    //public $username = "";
   // public $password = "";
//}  

switch($action)
{
	case 'Authenticate':
	//include('signup.php');
	$username = $_POST['username'];
	$password = $_POST['password'];
	//echo $username;
	//echo $password;
	//$password = password_hash($password, PASSWORD_DEFAULT);
	//echo $password;

	//echo $username;
	//echo $password;
	//$isAdmin= $_POST['isAdmin'];
	//$AUser = new user;
	$AUser = getUser($username);
	//$AUser->Password;
	foreach($AUser as $User) :
		//echo $User['UserName'];
		//echo $User['Password'];
		//endforeach;==

if(password_verify($password, $User['Password']))
{ 
		$_SESSION["UserName"] = $username;
		$_SESSION["Loggedin"] = true;
		if ($User['IsAdmin'] == 0)
		{
		//echo $username;
	//header('Location: ../Cars/index.php'.'?UserName='. $username);
		header('Location: ../Cars/CarChoose.php');
			echo $User['IsAdmin'];
		} 
	
	if($User['IsAdmin'] != 0)
	{
		//echo $User['IsAdmin'];
		header('Location: ../Admin/Index.php');
	}
}

/*else if(password_verify($password, $User['Password']) && $User['IsAdmin'] == 1)
{
	$_SESSION["UserName"] = $username;
		$_SESSION["Loggedin"] = true;
		header('Location: ../Admin/Index.php');
}*/

else{
	echo 'not correct';
}
	endforeach;
	//the password isn't the hashed password. fix this
	//echo $AUser['username'];
 //foreach ($AUser as $User):
 		//echo $User['username'];

 	
	break;

}
?>