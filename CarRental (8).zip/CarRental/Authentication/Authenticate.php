<!Doctype html>
<head>
</head>
<body>
<form action="index.php" method="POST" value="Authenticate">
<input name="username" type="text"/>
<input name = "password" type="text"/>
<input type="submit" value = "submit"/>
</form>
<a href="AccountSignUp/signup.php"/>Don't have an account? Sign Up Now!</a>
</html>