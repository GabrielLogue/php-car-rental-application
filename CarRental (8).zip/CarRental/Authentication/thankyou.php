<!Doctype html>
<head>
</head>
<body>
<h1>Thank you for signing in!</h1>
<a href="../index.php">Return home</a>
</body>
</html>