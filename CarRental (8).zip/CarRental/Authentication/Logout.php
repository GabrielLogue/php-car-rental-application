<?php
session_start();
session_unset();
session_destroy();
?>

<head>
  <link href="../https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../materialize/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../materialize/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
   <nav class="nav-extended blue lighten 1 col s12">
    <div class="nav-wrapper blue lighten 1">
      <a href="#!" class="brand-logo center">Cars</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.php">Home</a>
          <li><a href="../Authentication/logout.php">Logout</a>
      </ul>
    </div>
    <div class="sidenav left hide-on-med-and-large">
    </div>
    <div class="nav-content">
      <span class="nav-title"></span>
    </div>
  </nav>  
  <p>Thanks for logging out</p>
  <a href="../index.php">Log Back In</a>